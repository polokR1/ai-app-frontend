
import images from './images';

const HEADER_HEIGHT = 20;
const TAB_BAR_HEIGHT = 90;
const TAB_HEIGHT = 44;

export {  images, HEADER_HEIGHT, TAB_BAR_HEIGHT, TAB_HEIGHT };