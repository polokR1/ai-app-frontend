export default {
    username: 'Nombre de usuario',
    password: 'Contraseña',
    email: 'Correo electrónico',
    login: 'Acceso',
    welcome: 'Bienvenido',
    register: 'Registro',
    forgotPassword: 'Has olvidado tu contraseña?',
    loginWithSocials: 'O inicia sesión con una cuenta social'
   };