import common from './common';
import language from '../language';

export default {
	common,
	language,
};