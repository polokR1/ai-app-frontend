export default {
	english: 'English',
	spanish: 'Spanish',
	french: 'française'
};