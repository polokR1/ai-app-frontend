import { StyleSheet } from 'react-native';

export const styles = (height?) => StyleSheet.create({
    container: {
        height
    },
});